# Forecasting trajectories

- `generate_forecasts_trajectories.ipynb`: Shows training of a model from quantized abundance data and usage to generate forecasts
  - References this quantizer: https://zenodo.org/record/7453697/files/forecast_quantizer.pkl
- `abundance_data_quant.txt`, `features.csv`: quantized abundance data and feature names used for model training