===============
Example Data
===============



.. class:: no-web no-pdf

:Source: https://microbiomedb.org
:Original Publication: Bokulich, Nicholas A., et al. "Antibiotics, birth mode, and diet shape microbiome maturation during early life." Science translational medicine 8.343 (2016): 343ra82-343ra82.


